import { Component} from '@angular/core';
import { AngularFire, AuthProviders, AuthMethods } from 'angularfire2';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  user: any;
  constructor(public af: AngularFire) {
    this.af.auth.subscribe(user => {
      if(user){
        this.user = user;
      } else {
        user = null;
      }
    });
  }

  overrideLogin() {
    this.af.auth.login({
      provider: AuthProviders.Anonymous,
      method: AuthMethods.Anonymous,
    });

        // Anonymous
    this.af.auth.login({
      provider: AuthProviders.Anonymous,
      method: AuthMethods.Anonymous,
    });

    // Email and password
    this.af.auth.login({
      email: 'email@example.com',
      password: 'password',
    },
    {
      provider: AuthProviders.Password,
      method: AuthMethods.Password,
    });



    // Social provider popup
    this.af.auth.login({
      provider: AuthProviders.Github,
      method: AuthMethods.Popup,
    });
  }
}
